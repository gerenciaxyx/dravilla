<?php
include_once QODE_NEWS_LIKE_PATH.'/like.php';
include_once QODE_NEWS_LIKE_PATH.'/like-functions.php';