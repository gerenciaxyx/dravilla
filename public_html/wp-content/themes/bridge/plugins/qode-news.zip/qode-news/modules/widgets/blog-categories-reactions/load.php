<?php

include_once QODE_NEWS_WIDGETS_PATH.'/blog-categories-reactions/functions.php';
include_once QODE_NEWS_WIDGETS_PATH.'/blog-categories-reactions/blog-categories-reactions.php';