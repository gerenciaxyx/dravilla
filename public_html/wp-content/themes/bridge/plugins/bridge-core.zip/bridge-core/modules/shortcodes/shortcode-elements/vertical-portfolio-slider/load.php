<?php

include_once BRIDGE_CORE_SHORTCODES_PATH.'/vertical-portfolio-slider/vertical-portfolio-slider.php';
include_once BRIDGE_CORE_SHORTCODES_PATH.'/vertical-portfolio-slider/helper-functions.php';